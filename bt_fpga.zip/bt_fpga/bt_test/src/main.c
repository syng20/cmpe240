#include <stdio.h>
#include <xuartlite.h>
#include <xparameters.h>
#include <xil_printf.h>

#define uart_id XPAR_UARTLITE_0_DEVICE_ID

XUartLite uart;



int main()
{
	char msg[] = "xmit via uart\n\r";
	char buffer[100] ;
	int counter = 0;
	XUartLite_Initialize(&uart, uart_id);

	XUartLite_Send(&uart, msg, sizeof(msg));

	for ( int i=0; i<100; i++)
		buffer[i] = 0;

	xil_printf("Message for build-in console\n\r");

	while (1)
	{
		XUartLite_Recv(&uart, &buffer[counter], 1);
		if ( buffer[counter] == 0 )
			continue ;
		if ( buffer[counter++] == '.' )
		{
			buffer[counter] = 10;
			xil_printf(buffer);
			sleep(1);
			for ( int i=0; i<=counter; i++)
				buffer[i] = 0;
			counter = 0;
		}
//		sleep(1);
	}

	return 0 ;
}
