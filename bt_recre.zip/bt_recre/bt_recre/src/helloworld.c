#include <stdio.h>
#include <xuartlite.h>
#include <xparameters.h>
#include <xil_printf.h>

#define uart_id XPAR_UARTLITE_0_DEVICE_ID

XUartLite uart;


void choices (char* buffer, int counter) {
	char msg[] = "hehee\n\r";
	char mgs[] = "oops\n\r";

}

int main()
{
	char msg[] = "xmit via uart\n\r";
	char buffer[10];
	int counter = 0;
	XUartLite_Initialize(&uart, uart_id);

	XUartLite_Send(&uart, msg, sizeof(msg));

	int start = 0;
	int blocked = 0;

	for ( int i=0; i<10; i++)
		buffer[i] = 0;

	xil_printf("Message for build-in console\n\r");

	while (1)
	{
		blocked = *(unsigned int*)0x41220000;
		XUartLite_Recv(&uart, &buffer[counter], 1);
		if ( buffer[counter] == 0 )
			continue ;
		if (buffer[counter] == 13 || buffer[counter] == 10 ) {
			if (buffer[0] == 's') {
				start = !start;
				if (start && !blocked) *(unsigned int*)0x41200000 = 4;
				else *(unsigned int*)0x41200000 = 0;
			} else if (start) {
				switch(buffer[0]) {
					case 'f':
						if (!blocked) {
							if(buffer[1] == 'f') *(unsigned int*)0x41200000 = 4;
							else *(unsigned int*)0x41200000 = 3;
						}
						break;
					case 'b':
						if(buffer[1] == 'f') *(unsigned int*)0x41200000 = 2;
						else *(unsigned int*)0x41200000 = 1;
						break;
					case 'l':
						*(unsigned int*)0x41210000 = 3;
						break;
					case 'r':
						*(unsigned int*)0x41210000 = 4;
						break;
					case 'c':
						*(unsigned int*)0x41210000 = 0;
						break;
					default:
						*(unsigned int*)0x41200000 = 0;
						XUartLite_Send(&uart, msg, sizeof(msg));
						break;
				}

			} // end if start

			for ( int i=0; i<=counter; i++)
				buffer[i] = 0;
			counter = 0;

		} // end buffer check
		else counter++;



	}

	return 0 ;
}
